test = {
  'names': [
    'q02',
    '2',
    'q2'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> take_turn(2, 0,  make_test_dice(4, 6, 1))
        54869915c6e229fa125c6e1fd6a5bc42
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(3, 20, make_test_dice(4, 6, 1))
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(0, 35)
        29d3b4001d2bc5a27c1b4fbf39115d2e
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(0, 71)
        909f53322f7642e0b1bda481362e358a
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> take_turn(0, 7)
        0f684fbb002bfbe1b50be63aab6e3595
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}