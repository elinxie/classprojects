test = {
  'names': [
    'q08',
    'q8',
    '8'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(0, 0)
        e00e4488afbd4da854525c2d455f1e14
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(70, 50)
        e00e4488afbd4da854525c2d455f1e14
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(50, 70)
        311a5a92b1c90703ad58ca8a175e9c01
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(32, 4, 5, 4)
        311a5a92b1c90703ad58ca8a175e9c01
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(20, 25, 5, 4)
        8d231806203a2520d39821e394f84c2a
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}