info = {
  'hash_key': 'zr4vg22ju479lp5vtwq6uuafyjxfofnniim75cr5yokl0az28ouyawtupkn3fcpztvr2aoz2bmxkt1tr75ex9o6x8wmi1w2shy0jw4mzgxzv9748q9qktm2o5h2es96s',
  'name': 'proj1',
  'params': {
    'doctest': {
      'cache': """
      import hog
      from hog import *
      """
    }
  },
  'src_files': [
    'hog.py'
  ],
  'version': '1.0'
}