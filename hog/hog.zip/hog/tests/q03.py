test = {
  'names': [
    'q03',
    '3',
    'q3'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> select_dice(4, 24) == six_sided
        b762d93a1f05694db6324a1381bf043f
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> select_dice(16, 64) == six_sided
        3cefbe0ab2fcb709f694c0a99154a1ca
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> select_dice(0, 0) == six_sided
        b762d93a1f05694db6324a1381bf043f
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> select_dice(50, 80) == six_sided
        3cefbe0ab2fcb709f694c0a99154a1ca
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}