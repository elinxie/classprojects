test = {
  'names': [
    'q04',
    '4',
    'q4'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(1, 1, goal=100) # start can be 0 or 1
        >>> score0
        56e83896ebab2da2a5aa62458573c44a
        # locked
        >>> score1
        56e83896ebab2da2a5aa62458573c44a
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(2, 7, goal=100)
        >>> score0
        311a5a92b1c90703ad58ca8a175e9c01
        # locked
        >>> score1
        54869915c6e229fa125c6e1fd6a5bc42
        # locked
        >>> start
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(8, 3, goal=100)
        >>> score0
        54869915c6e229fa125c6e1fd6a5bc42
        # locked
        >>> score1
        311a5a92b1c90703ad58ca8a175e9c01
        # locked
        >>> start
        311a5a92b1c90703ad58ca8a175e9c01
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(4, 3, goal=100)
        >>> score0
        29d3b4001d2bc5a27c1b4fbf39115d2e
        # locked
        >>> score1
        8d231806203a2520d39821e394f84c2a
        # locked
        >>> start
        311a5a92b1c90703ad58ca8a175e9c01
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(3, 4, goal=100)
        >>> score0
        8d231806203a2520d39821e394f84c2a
        # locked
        >>> score1
        29d3b4001d2bc5a27c1b4fbf39115d2e
        # locked
        >>> start
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}