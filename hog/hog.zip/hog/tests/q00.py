test = {
  'names': [
    'q00',
    '0',
    'q0'
  ],
  'points': 0,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> test_dice = make_test_dice(4, 1, 2)
        >>> test_dice()
        8d231806203a2520d39821e394f84c2a
        # locked
        >>> test_dice() # Second call
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        >>> test_dice() # Third call
        88be95979b03acff523e009807a2c932
        # locked
        >>> test_dice() # Fourth call
        8d231806203a2520d39821e394f84c2a
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}