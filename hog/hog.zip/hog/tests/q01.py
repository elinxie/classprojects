test = {
  'names': [
    'q01',
    '1',
    'q1'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> roll_dice(2, make_test_dice(4, 6, 1))
        54869915c6e229fa125c6e1fd6a5bc42
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> roll_dice(3, make_test_dice(4, 6, 1))
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> roll_dice(3, make_test_dice(1, 2, 3))
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> counted_dice = make_test_dice(4, 1, 2, 6)
        >>> roll_dice(3, counted_dice)
        1a3f80d204b700c77c78a11b029fb74a
        # locked
        >>> roll_dice(1, counted_dice)  # Make sure you call dice exactly num_rolls times!
        eec6fea9b7994a1982d11a4ea920b462
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}