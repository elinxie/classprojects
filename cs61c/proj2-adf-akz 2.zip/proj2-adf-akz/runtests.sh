make

./assembler input/combined.s out/combined.int out/combined.out 


./assembler input/comments.s out/comments.int out/comments.out 


./assembler input/imm.s out/imm.int out/imm.out 

./assembler input/jumps.s out/jumps.int out/jumps.out 

./assembler input/labels.s out/lables.int out/labels.out 

./assembler input/p1_errors.s out/p1_errors.int out/p1_errors.out

./assembler input/p2_errors.s out/p2_errors.int out/p2_errors.out

./assembler input/pseudo.s out/pseudo.int out/pseudo.out

./assembler input/rtypes.s out/rtypes.int out/rtypes.out

./assembler input/simple.s out/simple.int out/simple.out
    
echo combined                   
diff out/combined.out out/ref/combined_ref.out
echo comments
diff out/comments.out out/ref/comments_ref.out
echo imm
diff out/imm.out out/ref/imm_ref.out
echo jumps
diff out/jumps.out out/ref/jumps_ref.out
echo labels 
diff out/labels.out out/ref/labels_ref.out
echo p1_errors

diff out/p1_errors.out out/ref/p1_errors_ref.out

echo p2_errors
diff out/p2_errors.out out/ref/p2_errors_ref.out

echo pseudo
diff out/pseudo.out out/ref/pseudo_ref.out

echo rtypes
diff out/rtypes.out out/ref/rtypes_ref.out

echo simple
diff out/simple.out out/ref/simple_ref.out
