make

 ./run-valgrind ./assembler -p1 input/combined.s out/combined.int out/combined.out
 ./run-valgrind ./assembler -p1 input/comments.s out/comments.int out/comments.out
 ./run-valgrind ./assembler -p1 input/imm.s out/imm.int out/imm.out
 ./run-valgrind ./assembler -p1 input/jumps.s out/jumps.int out/jumps.out
 ./run-valgrind ./assembler -p1 input/labels.s out/lables.int out/labels.out
 ./run-valgrind ./assembler -p1 input/p1_errors.s out/p1_errors.int out/p1_errors.out
 ./run-valgrind ./assembler -p1 input/p2_errors.s out/p2_errors.int out/p2_errors.out
 ./run-valgrind ./assembler -p1 input/pseudo.s out/pseudo.int out/pseudo.out
 ./run-valgrind ./assembler -p1 input/rtypes.s out/rtypes.int out/rtypes.out
 ./run-valgrind ./assembler -p1 input/simple.s out/simple.int out/simple.out
 ./run-valgrind ./assembler -p1 testmips1.s intermediateMips1.text finalMips1.txt
 ./run-valgrind ./assembler -p1 first1posshift.s intermediateMips2.text finalMips2.txt
 ./run-valgrind ./assembler -p1 psuedoinstructionstest.s intermediateMips3.text finalMips3.txt
echo combined
diff out/combined.out out/ref/combined_ref.out
echo comments
diff out/comments.out out/ref/comments_ref.out
echo imm
diff out/imm.out out/ref/imm_ref.out
echo jumps
diff out/jumps.out out/ref/jumps_ref.out
echo labels
diff out/labels.out out/ref/labels_ref.out
echo p1_errors

diff out/p1_errors.out out/ref/p1_errors_ref.out

echo p2_errors
diff out/p2_errors.out out/ref/p2_errors_ref.out

echo pseudo
diff out/pseudo.out out/ref/pseudo_ref.out

echo rtypes
diff out/rtypes.out out/ref/rtypes_ref.out

echo simple
diff out/simple.out out/ref/simple_ref.out./assembler input/combined.s out/combined.int out/combined.out


