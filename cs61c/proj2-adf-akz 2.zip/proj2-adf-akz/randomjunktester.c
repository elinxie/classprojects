#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "tables.h"
#include "translate_utils.h"
#include "translate.h"

int main(int argc, char const *argv[])
{
	
	char* token;
	token = strtok(NULL, IGNORE_CHARS);

	return 0;
}