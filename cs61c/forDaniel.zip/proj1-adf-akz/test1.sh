make beargit
beargit init
touch text.txt
touch hello.txt
touch hi.txt
beargit add text.txt
beargit add hello.txt
beargit add hi.txt
beargit status
beargit rm hello.txt
beargit status
